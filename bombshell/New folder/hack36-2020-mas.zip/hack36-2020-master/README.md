# Hack36 - 2020
This is the official website of HACK36 2020, MNNIT Allahabad.

Make sure to put some stars to my repos too.
